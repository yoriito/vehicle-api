# cpplint summary

- Total: **5208**

## Category list

| Category | Count |
|---|---:|
| `build/include_subdir` | 3544 |
| `whitespace/indent_namespace` | 1664 |